clc;
clear all;
inFile =xlsread("Readexcel_1.xlsx");
VoltageA=inFile(:,1);
VoltageB=inFile(:,2);
Im0=inFile(:,3);
Im1=inFile(:,4);
Im2=inFile(:,5);
InA=reshape(Im0,[8,8]);
InB=reshape(Im1,[8,8]);
InC=reshape(Im2,[8,8]);

figure (1);
colormap summer

surf(0:0.1:0.7,0:0.1:0.7,InA);
hold on;
surf(0:0.1:0.7,0:0.1:0.7,InB);
surf(0:0.1:0.7,0:0.1:0.7,InA);
figure (2);
contour(0:0.1:0.7,0:0.1:0.7,InB-InA,[0 0]);
hold on;
contour(0:0.1:0.7,0:0.1:0.7,InC-InB,[0 0]);
contour(0:0.1:0.7,0:0.1:0.7,InC-InA,[0 0]);
